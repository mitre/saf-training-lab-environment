control "SV-230536" do
  title "RHEL 8 must not send Internet Control Message Protocol (ICMP) redirects."
  desc "ICMP redirect messages are used by routers to inform hosts that a more direct route exists for a 
particular destination. These messages contain information from the system's route table, 
possibly revealing portions of the network topology.

There are notable differences 
between Internet Protocol version 4 (IPv4) and Internet Protocol version 6 (IPv6). There is 
only a directive to disable sending of IPv4 redirected packets. Refer to RFC4294 for an 
explanation of \"IPv6 Node Requirements\", which resulted in this difference between IPv4 and 
IPv6.

The sysctl --system command will load settings from all system configuration files. 
All configuration files are sorted by their filename in lexicographic order, regardless of 
which of the directories they reside in. If multiple files specify the same option, the entry 
in the file with the lexicographically latest name will take precedence. Files are read from 
directories in the following list from top to bottom. Once a file of a given filename is loaded, 
any file of the same name in subsequent directories is ignored.
/etc/sysctl.d/*.conf
/run/sysctl.d/*.conf
/usr/local/lib/sysctl.d/*.conf
/usr/lib/sysctl.d/*.conf
/lib/sysctl.d/*.conf
/etc/sysctl.conf"
  desc "check", "Verify RHEL 8 does not IPv4 ICMP redirect messages.

Note: If IPv4 is disabled on the system, 
this requirement is Not Applicable.

Check the value of the \"all send_redirects\" variables 
with the following command:

$ sudo sysctl 
net.ipv4.conf.all.send_redirects

net.ipv4.conf.all.send_redirects = 0

If the 
returned line does not have a value of \"0\", or a line is not returned, this is a finding.

Check 
that the configuration files are present to enable this network parameter.

$ sudo grep -r 
net.ipv4.conf.all.send_redirects /run/sysctl.d/*.conf 
/usr/local/lib/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /lib/sysctl.d/*.conf 
/etc/sysctl.conf /etc/sysctl.d/*.conf

/etc/sysctl.d/99-sysctl.conf: 
net.ipv4.conf.all.send_redirects = 0

If \"net.ipv4.conf.all.send_redirects\" is not 
set to \"0\", is missing or commented out, this is a finding.

If results are returned from more 
than one file location, this is a finding."
  desc "fix", "Configure RHEL 8 to not allow interfaces to perform IPv4 ICMP redirects.

Add or edit the 
following line in a system configuration file, in the \"/etc/sysctl.d/\" 
directory:

net.ipv4.conf.all.send_redirects=0

Load settings from all system 
configuration files with the following command:

$ sudo sysctl --system"
  impact 0.5
  tag severity: "medium"
  tag gtitle: "SRG-OS-000480-GPOS-00227"
  tag gid: "V-230536"
  tag rid: "SV-230536r818851_rule"
  tag stig_id: "RHEL-08-040220"
  tag fix_id: "F-33180r818850_fix"
  tag cci: ["CCI-000366"]
  tag nist: ["CM-6 b"]
end